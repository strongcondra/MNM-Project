<?php
	//STARTING THE SESSION
	session_start();
	
	//WHETHER OR NOT TO SHOW ERRORS
	ini_set('display_errors', false);
	ini_set('error_reporting', E_ALL);

	//PATH OF THE SYSTEM RELATIVE TO THE htdocs DIRECTORY
	$base_url = "/admin/";
	$root_dir = $_SERVER['DOCUMENT_ROOT'] . "/admin/";
	$client_url = "/";
	$client_dir = $_SERVER['DOCUMENT_ROOT'] . "/";
	
	//TIMEZONE SETTINGS
	date_default_timezone_set('Africa/Harare');

	//DATABASE CREDENTIALS

    $database_name = "u673078778_cafe";
	$database_user = "u673078778_cafe";
	$database_user_password = '*(SDF&*(^(SDF^&*^&*SD^F&*^&*^SD*3fF';
	$database_host = "localhost";
?>